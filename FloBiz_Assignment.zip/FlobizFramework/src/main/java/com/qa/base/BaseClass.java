// this class is containing some common methods(like method to read property file) and common variables(Response time codes)..!!

package com.qa.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class BaseClass {

	public int RESPONSE_STATUS_CODE_200 = 200; // OK Successful.
	public int RESPONSE_STATUS_CODE_201 = 201; // Created
	public int RESPONSE_STATUS_CODE_400 = 400; // Bad Request
	public int RESPONSE_STATUS_CODE_401 = 401; // Unauthorized
	public int RESPONSE_STATUS_CODE_403 = 403; // Forbidden
	public int RESPONSE_STATUS_CODE_500 = 500; // Internal Server Error

	public Properties prop;

	public BaseClass() {

		try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream(
					System.getProperty("user.dir") + "/src/main/java/com/qa/config/config.properties");
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
