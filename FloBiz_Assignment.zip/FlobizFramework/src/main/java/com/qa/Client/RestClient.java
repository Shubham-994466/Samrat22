// this class contains definitions for GET/POST/PUT methods which hits the appropriate request.

package com.qa.Client;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class RestClient {

	// 1. GET METHOD WITHOUT HEADERS
	public CloseableHttpResponse get(String url) throws ClientProtocolException, Throwable {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpGet httpget = new HttpGet(url); // enter url
		CloseableHttpResponse Response = httpClient.execute(httpget); // hit the URL

		return Response;
	}

	// 2. GET METHOD WITH HEADERS
	public CloseableHttpResponse get(String url, HashMap<String, String> headerMap)
			throws ClientProtocolException, IOException {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpGet httpget = new HttpGet(url); // enter url

		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			httpget.addHeader(entry.getKey(), entry.getValue());
		}
		CloseableHttpResponse Response = httpClient.execute(httpget); // hit the URL
		return Response;

	}

	// 3. POST Method:
	public CloseableHttpResponse post(String url, String entityString, HashMap<String, String> headerMap)
			throws ClientProtocolException, IOException {
		CloseableHttpClient httpClient = HttpClients.createDefault();

		// enter url :
		HttpPost httppost = new HttpPost(url);

		// for payload :
		httppost.setEntity(new StringEntity(entityString));

		// for headers:
		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			httppost.addHeader(entry.getKey(), entry.getValue());
		}

		CloseableHttpResponse Response = httpClient.execute(httppost);
		return Response;

	}

	// 4. PUT Method :
	public CloseableHttpResponse put(String url, String entityString, HashMap<String, String> headerMap)
			throws ClientProtocolException, IOException {
		CloseableHttpClient httpClient = HttpClients.createDefault();

		// enter url :
		HttpPut httpput = new HttpPut(url);

		// for payload :
		httpput.setEntity(new StringEntity(entityString));

		// for headers :
		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			httpput.addHeader(entry.getKey(), entry.getValue());
		}

		CloseableHttpResponse Response = httpClient.execute(httpput);
		return Response;

	}

}
