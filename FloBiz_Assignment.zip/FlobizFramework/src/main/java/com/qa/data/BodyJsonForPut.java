package com.qa.data;

public class BodyJsonForPut {

	String title;

	public BodyJsonForPut() {
	}

	public BodyJsonForPut(String title) {
		this.title = title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
