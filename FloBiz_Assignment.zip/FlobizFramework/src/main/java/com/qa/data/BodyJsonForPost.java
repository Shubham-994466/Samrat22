package com.qa.data;


public class BodyJsonForPost {

	String description;
	String fromemail;
	String title;
	String _id;
	String name;
	String message;

	public BodyJsonForPost() {

	}

	public BodyJsonForPost(String description, String fromemail, String title, String _id) {
		this.description = description;
		this.fromemail = fromemail;
		this.title = title;
		this._id = _id;
	}

	public BodyJsonForPost(String title) {
		this.title = title;
	}

	// getters and setters methods:
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFromemail() {
		return fromemail;
	}

	public void setFromemail(String fromemail) {
		this.fromemail = fromemail;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getID() {
		return _id;
	}

	public void setID(String _id) {
		this._id = _id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}