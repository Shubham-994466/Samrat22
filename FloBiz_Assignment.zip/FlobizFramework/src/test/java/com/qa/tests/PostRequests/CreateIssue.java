package com.qa.tests.PostRequests;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qa.Client.RestClient;
import com.qa.Util.TestUtil;
import com.qa.base.BaseClass;
import com.qa.data.BodyJsonForPost;

public class CreateIssue extends BaseClass {

	BaseClass testBase;
	String url;             // fixed 'uniform resource locator'.
	String endpointUrl;    // for endpoints
	String uri;            // final 'uniform resource identifier' used for reuest
	CloseableHttpResponse closehttpresponse;   // for storing httpResponse
	
	@BeforeMethod
	public void setup() {
		testBase = new BaseClass();
		url = prop.getProperty("URL");
		endpointUrl = prop.getProperty("serviceURL");
	}
	
	@Test
	public void postRequestToCreateIssue() throws JsonGenerationException, JsonMappingException, IOException {
		
		uri = url + endpointUrl;						
		
		RestClient restClient = new RestClient();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		headerMap.put("x-apikey", "5da6fb5d3cbe87164d4bb35d");
		
		// using Object Mapper to store "Payloads" 
		ObjectMapper mapper = new ObjectMapper();
		BodyJsonForPost users = new BodyJsonForPost("This is a new issue", "samrat006090@gmail.com","New Issue" ,"12134"); //expected users object
		
		//writing payload values in json file  :
		mapper.writeValue(new File(System.getProperty("user.dir") + "/src/main/java/com/qa/data/BodyJsonForPost.json"),users);
		
		//java object to json in String:
		String usersJsonString = mapper.writeValueAsString(users);
		System.out.println(usersJsonString);
		
		// storing response by hitting "POST" request for mentioned URI(uniform resource identifier)
		closehttpresponse = restClient.post(uri, usersJsonString, headerMap);          
		
		//API RESPONSE VALIDATION -:
		
		// 1. validate status code:
		int statusCode = closehttpresponse.getStatusLine().getStatusCode();
		System.out.println("Status is : -->"+statusCode);
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_500, "Status Code should match");
		
		//2. validate response in JsonString:
		String responseString = EntityUtils.toString(closehttpresponse.getEntity(), "UTF-8");
		
		JSONObject responseJson = new JSONObject(responseString);
		System.out.println("The response from API is:"+ responseJson);
		String name = TestUtil.getValueByJPath(responseJson, "/name");
		String message = TestUtil.getValueByJPath(responseJson, "/message");
		
		Assert.assertEquals(name, "Error", "Name should match");
		Assert.assertEquals(message, "ProcessTerminatedError: cancel after 1 retries!", "Message should match");		
	}
	
}
