package com.qa.tests.PutRequests;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qa.Client.RestClient;
import com.qa.Util.TestUtil;
import com.qa.base.BaseClass;
import com.qa.data.BodyJsonForPut;

public class ModifyIssue extends BaseClass {

	BaseClass testBase;
	String url;             // fixed 'uniform resource locator'.
	String endpointUrl;    // for endpoints
	String uri;            // final 'uniform resource identifier' used for reuest
	CloseableHttpResponse closehttpresponse;   // for storing httpResponse
	
	@BeforeMethod
	public void setup() {
		testBase = new BaseClass();
		url = prop.getProperty("URL");
		endpointUrl = prop.getProperty("serviceURL");
	}
	
	@Test
	public void putRequestToModifyIssue() throws JsonGenerationException, JsonMappingException, IOException {
		
          uri = url + endpointUrl +"/588893fbf54b5f59000003ce";     
		
		RestClient restClient = new RestClient();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		headerMap.put("x-apikey", "5da6fb5d3cbe87164d4bb35d");  
		
		// using Object Mapper to store "Payloads" 
		ObjectMapper mapper = new ObjectMapper();
		BodyJsonForPut users = new BodyJsonForPut("New Issue? NO problem, i will handle dude"); //expected users object
		
		//writing payload values in json file  :
		mapper.writeValue(new File(System.getProperty("user.dir") + "/src/main/java/com/qa/data/BodyJsonForPut.json"),users);
		//java object to json in String:
		String usersJsonString = mapper.writeValueAsString(users);
		System.out.println(usersJsonString);

		
		// storing response by hitting "PUT" request for mentioned URI(uniform resource identifier)
		closehttpresponse = restClient.put(uri, usersJsonString, headerMap); //call the API
		
		//API RESPONSE VALIDATION -:
		
		// 1. validate status code:
		int statusCode = closehttpresponse.getStatusLine().getStatusCode();
		System.out.println("Status is : -->"+statusCode);
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200, "Status Code should match");
		
		//2. validate response in JsonString:
		String responseString = EntityUtils.toString(closehttpresponse.getEntity(), "UTF-8");
		JSONObject responseJson = new JSONObject(responseString);
		System.out.println("The response from API is:"+ responseJson);
		
		String title = TestUtil.getValueByJPath(responseJson, "/title");
		Assert.assertEquals(title, "New Issue? NO problem, i will handle dude","Value Should Match for title");
		
	}

}
