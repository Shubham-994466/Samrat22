package com.qa.tests.GetRequests;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.Client.RestClient;
import com.qa.base.BaseClass;

public class ListALLIssues extends BaseClass {

	BaseClass testBase;
	String url;             // fixed 'uniform resource locator'.
	String endpointUrl;    // for endpoints
	String uri;            // final 'uniform resource identifier' used for reuest
	CloseableHttpResponse closehttpresponse;   // for storing httpResponse
	
	@BeforeMethod
	public void setup() {
		testBase = new BaseClass();
		url = prop.getProperty("URL");
		endpointUrl = prop.getProperty("serviceURL");
	}
	
	@Test
	public void getRequestToListAllIssues()throws ClientProtocolException, IOException {
		
		uri = url + endpointUrl;    
		
		RestClient restclient = new RestClient();
		
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		headerMap.put("x-apikey", "5da6fb5d3cbe87164d4bb35d");

		closehttpresponse = restclient.get(uri,headerMap);
		
		int Status = closehttpresponse.getStatusLine().getStatusCode();
		
	    System.out.println("Status is : -->"+Status);
		
		Assert.assertEquals(Status, RESPONSE_STATUS_CODE_200 ,"Status Code is not 200");	// to assert that all issues are fetched successfully
		
	}
	
}
