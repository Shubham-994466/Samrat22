package com.qa.tests.GetRequests;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.Client.RestClient;
import com.qa.Util.TestUtil;
import com.qa.base.BaseClass;

public class ListIssueByID extends BaseClass{

	BaseClass testBase;
	String url;             // fixed 'uniform resource locator'.
	String endpointUrl;    // for endpoints
	String uri;            // final 'uniform resource identifier' used for reuest
	CloseableHttpResponse closehttpresponse;   // for storing httpResponse
	
	@BeforeMethod
	public void setup() {
		testBase = new BaseClass();
		url = prop.getProperty("URL");
		endpointUrl = prop.getProperty("serviceURL");
	}
	
	@Test
	public void getRequestToListIssueById() throws ClientProtocolException, IOException {
		uri = url + endpointUrl + "/588893fbf54b5f59000003ce";  							// uniform resource identifier
		
		RestClient restclient = new RestClient();
		
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");									// Header one
		headerMap.put("x-apikey", "5da6fb5d3cbe87164d4bb35d");								// Header two
		
		closehttpresponse = restclient.get(uri,headerMap);     								// hitting get request and and storing response
		
		int Status = closehttpresponse.getStatusLine().getStatusCode();					    // fetching status from response
		
	    System.out.println("Status is : -->"+Status);									   	// printing status
		
		Assert.assertEquals(Status, RESPONSE_STATUS_CODE_200 ,"Status Code is not 200");     // asserting status
		
		String responseString = EntityUtils.toString(closehttpresponse.getEntity(),"UTF-8"); // converting response in string form
		JSONObject responseJson= new JSONObject(responseString);
		
		
		// fetching path parameters below -:
		
		String id = TestUtil.getValueByJPath(responseJson, "/_id");
		String description = TestUtil.getValueByJPath(responseJson, "/description");
		String customerID = TestUtil.getValueByJPath(responseJson, "/customer[0]/_id");
		String customerName = TestUtil.getValueByJPath(responseJson, "/customer[0]/name");
		String customerCreatedDateAndTime = TestUtil.getValueByJPath(responseJson, "/customer[0]/_created");
		String customerChangedDateAndTime = TestUtil.getValueByJPath(responseJson, "/customer[0]/_changed");
		String screenshot = TestUtil.getValueByJPath(responseJson, "/screenshots[0]");
		String fromemail = TestUtil.getValueByJPath(responseJson, "/fromemail");	
		String ticket = TestUtil.getValueByJPath(responseJson, "/ticket");
		String title = TestUtil.getValueByJPath(responseJson, "/title");
		String responsibleID = TestUtil.getValueByJPath(responseJson, "/responsible[0]/_id");
		String responsibleEmail = TestUtil.getValueByJPath(responseJson, "/responsible[0]/email");
		String responsibleName = TestUtil.getValueByJPath(responseJson, "/responsible[0]/name");
		String responsiblePhoto = TestUtil.getValueByJPath(responseJson, "/responsible[0]/photo[0]");
		String responsibleCreatedDateAndTime = TestUtil.getValueByJPath(responseJson, "/responsible[0]/_created");
		String responsibleChangedDateAndTime = TestUtil.getValueByJPath(responseJson, "/responsible[0]/_changed");
		String status = TestUtil.getValueByJPath(responseJson, "/status");
		String statusMessage = TestUtil.getValueByJPath(responseJson, "/status-message");
		
//		Asserting response :-
		
		Assert.assertEquals(id, "588893fbf54b5f59000003ce","Value Should Match for ID");
		Assert.assertEquals(description, "I'm loosing it now.\n\nWhat am I doing wrong??","Value Should Match for description");
		Assert.assertEquals(customerID, "5887dd51f54b5f59000000d8","Value Should Match for customerID");
		Assert.assertEquals(customerName, "restdb.io","Value Should Match for customerName");
		Assert.assertEquals(customerCreatedDateAndTime, "2017-01-24T23:03:45.332Z","Value Should Match for customerCreatedDateAndTime");
		Assert.assertEquals(customerChangedDateAndTime, "2017-01-25T11:45:37.126Z","Value Should Match for customerChangedDateAndTime");
		Assert.assertEquals(screenshot, "588893fbf54b5f59000003cd","Value Should Match for screenshot");
		Assert.assertEquals(fromemail, "jbeejones@gmail.com","Value Should Match for fromemail");
		Assert.assertEquals(ticket, "8JGK3","Value Should Match for ticket");
		Assert.assertEquals(title, "New Issue? NO problem, i will handle dude","Value Should Match for title");
		Assert.assertEquals(responsibleID, "5886f71fa4f1f47d00000444","Value Should Match for responsibleID");
		Assert.assertEquals(responsibleEmail, "jones@restdb.io","Value Should Match for responsibleEmail");
		Assert.assertEquals(responsibleName, "Jonnie Caseworker","Value Should Match for responsibleName");
		Assert.assertEquals(responsiblePhoto, "58876596f54b5f5900000004","Value Should Match for responsiblePhoto");
		Assert.assertEquals(responsibleCreatedDateAndTime, "2017-01-24T06:41:35.705Z","Value Should Match for responsibleCreatedDateAndTime");
		Assert.assertEquals(responsibleChangedDateAndTime, "2017-01-25T11:47:06.854Z","Value Should Match for responsibleChangedDateAndTime");
		Assert.assertEquals(status, "Working","Value Should Match for status");
		Assert.assertEquals(statusMessage, "It's fixed.\n\nCan you confirm, please?","Value Should Match for statusMessage");
	}
	
	
}
