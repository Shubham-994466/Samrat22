package utils;

import org.openqa.selenium.WebDriver;
import utils.Objects.UiElements;

import static utils.DriverFactory.browser;

public class OpenBrowser {

    static WebDriver driver  = DriverFactory.getDriver();

    public void openAppUrl(){
        driver.get("https://prod.100ms.live/");
        if(browser.equalsIgnoreCase("firefox")) {
            continueWithFirefoxBrowser();
        }
    }

    public void continueWithFirefoxBrowser(){
        driver.findElement(UiElements.continueWithCurrentBrowser).click();
    }

    static public void clickOnJoinInFireFox(){
        driver.findElement(UiElements.joinButtonInFirefox).click();
    }

    public void closeBrowser(){
        driver.close();
    }

    public void quitDriver(){
        driver.quit();
    }


}
