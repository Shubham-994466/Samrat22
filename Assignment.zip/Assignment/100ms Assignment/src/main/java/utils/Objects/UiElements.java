package utils.Objects;

import org.openqa.selenium.By;

public class UiElements {
    public static By createRoom = By.xpath("//button[text()='Create Room']");
    public static By joinRoom = By.xpath("//button[text()='Join Room']");
    public static By roomName = By.xpath("//input[@name='roomName']");
    public static By joinRoomName = By.xpath("//input[@name='displayName']");
    public static By userName = By.xpath("//input[@name='displayName']");
    public static By environment = By.xpath("//input[@name='env' and @label='Environment']");
    public static By submitCreateRoom = By.xpath("//button[@type='submit']");
    public static By submitJoinRoom = By.xpath("//button[@type='submit' and contains(@class,'group relative')]");
    public static By promptPermissionDialog = By.xpath("//button[contains(@class,'group relative')]");
    public static By camera = By.xpath("(//div[contains(@class,'w-10')])[1]");
    public static By joinButtonInFirefox = By.xpath("//button[contains(@class,'group relative w-full flex')]");
    public static By mic = By.xpath("(//div[contains(@class,'w-10')])[2]");
    public static By chatBox = By.xpath("(//div[contains(@class,'w-10')])[5]");
    public static By messageInputBox = By.xpath("//input[@placeholder='Please input message']");
    public static By sendMessageButton = By.xpath("//button[@class='ant-btn ant-btn-icon-only']");
    public static By roomIdInputBox = By.xpath("//input[@name='roomId']");
    public static By receivedMessage = By.xpath("//div[@class='bubble-msgword']/p");
    public static By continueWithCurrentBrowser = By.xpath("//button[contains(@class,'group relative w-full flex')]");
    public static By peerNameElement = By.xpath("//img[contains(@src,'https://ui-avatars.com/api/?background=random&name=')]");
}
