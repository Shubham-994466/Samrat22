package utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;

public class PropertyFileReaderUtils {


    public static String getPropertyValueForKey(String key) {

        try {
            FileReader freader = new FileReader("src/main/resources/100ms.properties");
            Properties p = new Properties();
            p.load(freader);
            String propertyValue = p.getProperty(key);
            return propertyValue;
        } catch (Exception e) {
            System.out.println(e);
        }

        return null;
    }
}
