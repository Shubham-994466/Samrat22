package utils;

import org.openqa.selenium.*;
import utils.Objects.UiElements;

import java.util.ArrayList;

public class CommonOperations {

    static String browser = PropertyFileReaderUtils.getPropertyValueForKey("browserName");
    WebDriver driver = DriverFactory.getDriver();

    public void createRoom(){
        driver.findElement(UiElements.createRoom).click();
        driver.findElement(UiElements.roomName).sendKeys("TestChat");
        driver.findElement(UiElements.userName).sendKeys("Peer 1");
        driver.findElement(UiElements.environment).sendKeys("qa-in");
        driver.findElement(UiElements.submitCreateRoom).click();
        sleep();
        driver.findElement(UiElements.promptPermissionDialog).click();
        if(browser.equalsIgnoreCase("firefox")){
            OpenBrowser.clickOnJoinInFireFox();
        }
        sleep();
    }

    public void disableCamera(){
        sleep();
        driver.findElement(UiElements.camera).click();
    }

    public void disableMic(){
        driver.findElement(UiElements.mic).click();
    }

    public void openChatWindow(){
        driver.findElement(UiElements.chatBox).click();
        sleep();
    }

    public String getRoomId(){
        String currentUrl = driver.getCurrentUrl();
        String splitByAnd[] = currentUrl.split("&");
        String splitByEqualsTo[] = splitByAnd[0].split("=");
        String roomId = splitByEqualsTo[1];
        System.out.println("Room Id is - "+roomId);
        return roomId;
    }

    public void typeAndSendMessage(String message){
        driver.findElement(UiElements.messageInputBox).sendKeys(message);
        driver.findElement(UiElements.sendMessageButton).click();
        sleep();
    }

    public void openNewTab(){

        sleep();

        String a = "window.open('https://prod.100ms.live/','_blank');";  // replace link with your desired link
        ((JavascriptExecutor)driver).executeScript(a);

        sleep();
    }

    public void switchToTab(String tabNo){
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        int tabIndex = -404;
            if (tabNo.equals("Peer_2_Tab")) {
                tabIndex = 1;
            } else if (tabNo.equalsIgnoreCase("Peer_1_Tab")) {
                tabIndex = 0;
            } else {
                System.out.println("Pass correct Tab No");
            }

            sleep();
            driver.switchTo().window(tabs.get(tabIndex));
    }

    public void joinRoomWithRoomId(String roomId){

        if(browser.equalsIgnoreCase("firefox")){
            OpenBrowser.clickOnJoinInFireFox();
        }
        sleep();

        driver.findElement(UiElements.joinRoom).click();
        driver.findElement(UiElements.roomIdInputBox).sendKeys(roomId);
        driver.findElement(UiElements.joinRoomName).sendKeys(Keys.CONTROL + "a");
        driver.findElement(UiElements.joinRoomName).sendKeys(Keys.DELETE);
        driver.findElement(UiElements.joinRoomName).sendKeys("Peer 2");
        driver.findElement(UiElements.environment).sendKeys("qa-in");
        driver.findElement(UiElements.submitJoinRoom).click();
        sleep();
        driver.findElement(UiElements.promptPermissionDialog).click();
        if(browser.equalsIgnoreCase("firefox")){
            OpenBrowser.clickOnJoinInFireFox();
        }
    }

    public int getCountOfPeersFromUIinMeetingRoom(){
        ArrayList<WebElement> peers = new ArrayList<WebElement>();
        peers = (ArrayList<WebElement>) driver.findElements(UiElements.peerNameElement);
        return peers.size();
    }

    public String readRecievedMessage(){
        String messageReceived = driver.findElement(UiElements.receivedMessage).getText();
        return messageReceived;
    }

    public void sleep(){
        try{
            Thread.sleep(3000);
        }catch (Exception e){
            System.out.println(e);
        }
    }

}
