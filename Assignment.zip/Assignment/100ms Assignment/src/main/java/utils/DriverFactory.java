package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.util.Locale;

public class DriverFactory {
    public static WebDriver driver = null;

    public static final String browser = PropertyFileReaderUtils.getPropertyValueForKey("browserName");

    public static WebDriver getDriver() {
        if (driver == null) {
            invokeBrowser(browser);
        }
        return driver;
    }

    public static void invokeBrowser(String browser) {

        String browsername = browser.toLowerCase(Locale.ROOT);

        switch (browsername) {
            case "chrome":
                System.setProperty("webdriver.chrome.driver",
                        "src/main/resources/drivers/chromedriver.exe");
                ChromeOptions options = new ChromeOptions();
                options.addArguments("use-fake-device-for-media-stream");
                options.addArguments("use-fake-ui-for-media-stream");

                driver = new ChromeDriver(options);
                break;
            case "firefox":
                System.setProperty("webdriver.gecko.driver",
                        "src/main/resources/drivers/latestgeckodriver/geckodriver.exe");
                FirefoxOptions opt = new FirefoxOptions();
                opt.addPreference("media.navigator.streams.fake", true);

                driver = new FirefoxDriver(opt);
                break;

        }
        driver.manage().window().maximize();

    }


}
