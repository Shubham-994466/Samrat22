import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils.CommonOperations;
import utils.OpenBrowser;

public class CreateAndJoinRoomTest {
    OpenBrowser ob = new OpenBrowser();
    CommonOperations commonFunctions = new CommonOperations();
    static ExtentTest test;
    static ExtentReports report;
    int expectedPeersInMeeting = 2;
    int actualPeersInMeeting;


    @BeforeSuite
    public void initialiseReports(){
        report = new ExtentReports("target/ExtentReports" + "\\ExtentReportResults_Chrome.html");
        test = report.startTest("ChatFunctionalityTest");
    }

    @BeforeMethod
    public void openBrowserWith100msURL() {
        ob.openAppUrl();
    }

    @Test()
    public void VerifyTheTotalPeersAndChatFunctionality() {
        String expectedMessage = "Hey This is Peer 2";
        //create room
        commonFunctions.createRoom();
        commonFunctions.disableCamera();
        commonFunctions.disableMic();
        String roomId = commonFunctions.getRoomId();
        commonFunctions.openChatWindow();

        commonFunctions.openNewTab();

        // room joined by Peer 2
        commonFunctions.switchToTab("Peer_2_Tab");
        commonFunctions.joinRoomWithRoomId(roomId);
        commonFunctions.disableCamera();
        commonFunctions.disableMic();

        //verify total number of peers
        actualPeersInMeeting = commonFunctions.getCountOfPeersFromUIinMeetingRoom();

        Assert.assertEquals(actualPeersInMeeting,expectedPeersInMeeting,"Expected Peers are not present in meeting");

        if(actualPeersInMeeting==expectedPeersInMeeting){
            test.log(LogStatus.PASS, "Correct Number of Peers in Meeting");
        } else {
            test.log(LogStatus.FAIL, "Test Failed, Mismatch in Number of Peers in Meeting");
        }

        commonFunctions.openChatWindow();
        commonFunctions.typeAndSendMessage(expectedMessage);

        // back to Peer 1 screen
        commonFunctions.switchToTab("Peer_1_Tab");


        // validate the text message sent by Peer 2
        String actualMessage = commonFunctions.readRecievedMessage();
        Assert.assertEquals(expectedMessage, actualMessage, "Message didn't matched.");

        if (expectedMessage.equalsIgnoreCase(actualMessage)) {
            test.log(LogStatus.PASS, "Correct Message Received from Peer 2");
        } else {
            test.log(LogStatus.FAIL, "Test Failed, Message didn't received successfully from Peer 2");
        }

    }

    @AfterMethod
    public void closeMeetingBrowser() {
        ob.closeBrowser();
    }

    @AfterSuite
    public void closeDriverAndCreateReport() {
        report.endTest(test);
        report.flush();
        ob.quitDriver();
    }

}
